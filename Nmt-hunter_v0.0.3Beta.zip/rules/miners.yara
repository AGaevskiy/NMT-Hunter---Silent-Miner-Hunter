// XMRig
rule Miner_XMRig {
    meta:
        description = "XMRig cryptocurrency miner"
        severity = "critical"
    strings:
        $s1 = "xmrig" wide ascii nocase
        $s2 = "stratum+tcp" wide ascii nocase
        $s3 = "donate-level" wide ascii nocase
        $s4 = "cpu-max-threads-hint" wide ascii nocase
        $h1 = { 58 4D 52 69 67 }  // XMRig in hex
    condition:
        any of them
}

// PhoenixMiner
rule Miner_Phoenix {
    meta:
        description = "PhoenixMiner"
        severity = "critical"
    strings:
        $s1 = "PhoenixMiner" wide ascii nocase
        $s2 = "ethminer" wide ascii nocase
        $s3 = "-epool" wide ascii nocase
        $s4 = "-ewal" wide ascii nocase
    condition:
        any of them
}

// Claymore
rule Miner_Claymore {
    meta:
        description = "Claymore miner"
        severity = "critical"
    strings:
        $s1 = "Claymore" wide ascii nocase
        $s2 = "EthDcrMiner" wide ascii nocase
        $s3 = "-epool" wide ascii nocase
    condition:
        any of them
}

// NBMiner
rule Miner_NBMiner {
    meta:
        description = "NBMiner"
        severity = "critical"
    strings:
        $s1 = "nbminer" wide ascii nocase
        $s2 = "NBMiner" wide ascii nocase
        $s3 = "--algo" wide ascii nocase
        $s4 = "--url" wide ascii nocase
    condition:
        any of them
}

// T-Rex
rule Miner_T_Rex {
    meta:
        description = "T-Rex miner"
        severity = "critical"
    strings:
        $s1 = "t-rex" wide ascii nocase
        $s2 = "t-rex.exe" wide ascii nocase
        $s3 = "--url" wide ascii nocase
        $s4 = "--user" wide ascii nocase
    condition:
        any of them
}

// lolMiner
rule Miner_LolMiner {
    meta:
        description = "lolMiner"
        severity = "critical"
    strings:
        $s1 = "lolminer" wide ascii nocase
        $s2 = "lolMiner" wide ascii nocase
        $s3 = "--pool" wide ascii nocase
    condition:
        any of them
}

// TeamRedMiner
rule Miner_TeamRed {
    meta:
        description = "TeamRedMiner"
        severity = "critical"
    strings:
        $s1 = "teamredminer" wide ascii nocase
        $s2 = "teamred" wide ascii nocase
        $s3 = "--algo" wide ascii nocase
    condition:
        any of them
}

// Generic miner patterns
rule Miner_Generic {
    meta:
        description = "Generic miner pattern"
        severity = "high"
    strings:
        $s1 = "stratum+tcp" wide ascii nocase
        $s2 = "donate-level" wide ascii nocase
        $s3 = "mining" wide ascii nocase
        $s4 = "hashrate" wide ascii nocase
        $s5 = "accepted" wide ascii nocase
    condition:
        ($s1 or $s2) and ($s3 or $s4 or $s5)
}